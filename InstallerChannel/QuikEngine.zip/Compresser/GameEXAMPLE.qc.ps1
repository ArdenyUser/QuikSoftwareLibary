Write-Host "Script Execution - OK"
wget [LINK TO DOWNLAOD OF WORKSPACE]
mkdir C:\QuikEngine
mkdir C:\QuikEngine\RG
Expand-Archive -Path 'doge'
cd C:\QuikEngine\RG\Data
cmd 1.cmd
[INCLUDE ANOTHER COMMAND WITH cmd N.cmd TO EXECUTE ANY OTHER CUSTOM FILES INSIDE OF DATA]
cd C:\QuikEngine\RG\Resources
cmd Qlib.cmd
powershell cd C:\QuikEngine\RG
rmdir C:\QuikEngine\RG\Resources
rmdir C:\QuikEngine\RG\Data
rmdir C:\QuikEngine\RG\Lots
rm C:\QuikEngine\RG\Qdataprep.cmd