rm 1.cmd
wget https://raw.githubusercontent.com/ArdenyUser/QuikSoftwareLibary/main/UpdaterChannel/1.cmd -OutFile 1.cmd
wget https://raw.githubusercontent.com/ArdenyUser/QuikSoftwareLibary/main/UpdaterChannel/moredata -OutFile updatertools.ps1
.\updatertools.ps1
rm updatertools.ps1
