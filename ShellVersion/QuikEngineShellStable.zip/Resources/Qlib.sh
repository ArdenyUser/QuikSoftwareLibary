cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT1
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT2
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT3
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT4
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT5
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT6
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT7
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots for 0/
cd ./LOT8
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi
cd /ShellQuikEngine/
cd ./Lots of 0
cd ./LOT9
if test -f "1.py"; then
    py 1.py
fi
if test -f "2.py"; then
    py 2.py
fi
if test -f "3.py"; then
    py 3.py
fi
if test -f "1.class"; then
    java 1.class
fi
if test -f "2.class"; then
    java 2.class
fi
if test -f "3.class"; then
    java 3.class
fi
if test -f "1.java"; then
    java 1.java
fi
if test -f "2.java"; then
    java 2.java
fi
if test -f "3.java"; then
    java 3.java
fi
if test -f "1.jar"; then
    java 1.jar
fi
if test -f "2.jar"; then
    java 2.jar
fi
if test -f "3.jar"; then
    java 3.jar
fi
if test -f "1.sh"; then
    sh 1.sh
fi
if test -f "2.sh"; then
    sh 2.sh
fi
if test -f "3.sh"; then
    sh 3.sh
fi