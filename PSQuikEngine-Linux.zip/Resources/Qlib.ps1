cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT1
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT2
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT3
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT4
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT5
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT6
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT7
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}

cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT8
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}
cd /QuikEngineGames/Dev/QuikEngine/LOTS/Lots0/LOT9
# Do the below command to make every file in this lot

if ( Test-Path -Path ./1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path ./2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path ./3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path ./1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path ./2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path ./3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path ./1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path ./2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path ./3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path ./1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path ./2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path ./3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path ./1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path ./2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path ./3.cmd -PathType Leaf ) {
    3.cmd
}
pause