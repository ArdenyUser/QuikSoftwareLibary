cd C:\
mdir QuikEngineGames
cd C:\QuikEngineGames
echo Game Setup Wizard EXTRACTION SETUP
Rename-Item 'GAMDECORE.zip' -Path 'gamefiles.qep' 
Expand-Archive -Path 'GAMECORE.zip'
echo Game Setup Wizard EXTRACTION
Rename-Item 'GAMDEDATA.zip' -Path 'gamecore.qed' 
Expand-Archive -Path 'GAMEDATA.zip'
mkdir System Docs
mkdir Engine Data
echo Game Setup Wizard EXTRACTION PT2
Rename-Item 'GAMDEDATA2.zip' -Path 'gameexecuter.qed' 
Expand-Archive -Path 'GAMEDATA2.zip'
echo Game Setup Wizard EXTRACTION PT3
mkdir Models
cd .\Models
Rename-Item 'GAMDEDATA3.zip' -Path 'gamemodels.qed' 
Expand-Archive -Path 'GAMEDATA3.zip'
pause
