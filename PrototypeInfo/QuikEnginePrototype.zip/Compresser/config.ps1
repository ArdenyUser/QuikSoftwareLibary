cd C:\
mkdir CCdatQuik
cd C:\CCdatQuik
mkdir LOT
mkdir LOT1
mkdir LOT2
mkdir LOT3
mkdir LOT4
mkdir LOT5
mkdir LOT6
mkdir LOT7
mkdir LOT8
mkdir LOT9
cd C:\CCdatQuik\LOT
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT
cd C:\CCdatQuik\LOT1
# Do the below command to make every file in this lot
Set-Content -Path .\1.py -Value 'print("HIIIII")'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT1
cd C:\CCdatQuik\LOT2
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT2
cd C:\CCdatQuik\LOT3
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT3
cd C:\CCdatQuik\LOT4
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT4
cd C:\CCdatQuik\LOT5
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT5
cd C:\CCdatQuik\LOT6
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT6
cd C:\CCdatQuik\LOT7
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT7
cd C:\CCdatQuik\LOT8
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT8
cd C:\CCdatQuik\LOT9
# Do the below command to make every file in this lot
Set-Content -Path .\File -Value 'Data'
if ( Test-Path -Path .\1.py -PathType Leaf ) {
    py 1.py
}
if ( Test-Path -Path .\2.py -PathType Leaf ) {
    py 2.py
}
if ( Test-Path -Path .\3.py -PathType Leaf ) {
    py 3.py
}
if ( Test-Path -Path .\1.class -PathType Leaf ) {
    java 1.class
}
if ( Test-Path -Path .\2.class -PathType Leaf ) {
    java 2.class
}
if ( Test-Path -Path .\3.class -PathType Leaf ) {
    java 3.class
}
if ( Test-Path -Path .\1.java -PathType Leaf ) {
    java 1.java
}
if ( Test-Path -Path .\2.java -PathType Leaf ) {
    java 2.java
}
if ( Test-Path -Path .\3.java -PathType Leaf ) {
    java 3.java
}
if ( Test-Path -Path .\1.jar -PathType Leaf ) {
    java 1.jar
}
if ( Test-Path -Path .\2.jar -PathType Leaf ) {
    java 2.jar
}
if ( Test-Path -Path .\3.jar -PathType Leaf ) {
    java 3.jar
}
if ( Test-Path -Path .\1.cmd -PathType Leaf ) {
    1.cmd
}
if ( Test-Path -Path .\2.cmd -PathType Leaf ) {
    2.cmd
}
if ( Test-Path -Path .\3.cmd -PathType Leaf ) {
    3.cmd
}
rmdir -Force C:\CCdatQuik\LOT9
pause
